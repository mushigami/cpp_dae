#pragma once
#include <string>

class Texture
{
public:
	Texture( const std::string& imagePath );
	Texture( const std::string& text, TTF_Font *pFont, const Color4f& textColor );
	Texture( const std::string& text, const std::string& fontPath, int ptSize, const Color4f& textColor );
	~Texture();

	void Draw( const Point2f& destBottomLeft, const Rectf& srcRect = {} );
	void Draw( const Rectf& destRect, const Rectf& srcRect = {} );

	float GetWidth();
	float GetHeight();
	bool IsCreationOk( );

private:
	//DATA MEMBERS
	GLuint m_Id{};
	float m_Width{ 10.0f };
	float m_Height{ 10.0f };
	bool m_CreationOk{};

	// FUNCTIONS
	void CreateFromImage( const std::string& path );
	void CreateFromString( const std::string& text, TTF_Font *pFont, const Color4f & textColor );
	void CreateFromString( const std::string& text, const std::string& fontPath, int ptSize, const Color4f& textColor );
	void CreateFromSurface( SDL_Surface *pSurface );
	void DrawFilledRect( const Point2f& dstBottomLeft );
};


