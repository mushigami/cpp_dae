#pragma once
#include "structs.h"
class Ball
{
public:
	Ball(Point2f position,	Vector2f velocity, Color4f color, float radius);
	void Update(float elapsedSeconds, const Rectf& r);
	void Draw();
private:
	void FillCircle(const Point2f & center, float radius, const Color4f & color);
	void GenerateColor();
	Point2f m_Position;
	Vector2f m_Velocity;
	Color4f m_Color;
	float m_Radius{};
};

