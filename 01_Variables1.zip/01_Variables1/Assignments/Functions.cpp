#include <iostream>
int main( )
{
	// 1. Show my data
	std::cout << "My name is name, firstname" << std::endl;
	std::cout << "I am in group 1DAExx" << std::endl << std::endl;

	// 2. Show my mentor's data
	std::cout << "My mentor is name, firstname" << std::endl;
	std::cout << "He/she is a ... lecturer" << std::endl << std::endl;


	// Wait
	std::cout << "Push ENTER to quit\n";
	std::cin.get( );

	return 0;
}

