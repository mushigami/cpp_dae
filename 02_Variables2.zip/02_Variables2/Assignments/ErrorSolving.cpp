#include <iostream>;
#include <string>

int main( )
{
	// 1. Calculate average result of 3 tests
	// Problem: Wrong total
	// Problem: Average should be rounded to 1 decimal
	int total{};
	std::cout << "The 1st test result? ";
	int testResult{};
	std::cin >> testResult;
	total += testResult;

	std::cout << "The 2nd test result? ";
	std::cin >> testResult;
	total = + testResult;

	std::cout << "The 3rd test result? ";
	std::cin >> testResult;
	total + testResult;
	std::cout << "Total: " << total << std::endl;

	float average{ total / 3.0 };
	std::cout << "Average result: " << average << std::endl;

	// 2. Generate 3 random numbers in the range [3,6]
	// 1st problem: Always same sequence
	// 2nd problem: Never number 6
	std::cout << "\nRandom numbers in the range [3, 6]\n";

	int randNr = rand( ) % 3 + 3;
	std::cout << randNr << std::endl;
	randNr = rand( ) % 3 + 3;
	std::cout << randNr << std::endl;
	randNr = rand( ) % 3 + 3;
	std::cout << randNr << std::endl;

	// 3. Square root function: sqrt
	float floatNr{};
	std::cout << "Enter a floating point value ";
	std::cin >> floatNr;
	float result{};
	result = sqrt( floatNr );
	std::cout << "Square root of this value is " << result << std::endl;

	int intNr{};
	std::cout << "Enter an integer value ";
	std::cin >> intNr;
	result = sqrt( intNr );
	std::cout << "Square root of this value is " << result << std::endl;


	// 4. Send ASCII value corresponding with the entered letter to cout
	// Problem : not the ASCII value but the entered letter is shown
	std::cout << "Enter a letter ";
	char letter{};
	std::cin >> letter;
	std::cout << "ASCII value of this letter is " << letter << std::endl;

	// 5. Send letter corresponding with the entered ASCII value to cout
	// Problem occurs when entering the ASCII value of a letter, e.g. 97 
	std::cout << "Enter ASCII value of a letter ";
	char ascii{};
	std::cin >> ascii;
	std::cout << "Letter corresponding with this ASCII value is " << ascii << std::endl;


	// 6. Wait until user presses ENTER
	// Problem: Application doesn't stop
	std::cout << "\nPush ENTER to quit";
	std::cin.get( );

	return 0;

